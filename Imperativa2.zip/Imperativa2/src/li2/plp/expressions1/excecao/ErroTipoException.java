package li2.plp.expressions1.excecao;

public class ErroTipoException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5279414744949285209L;

}
