package li2.plp.imperative1.memory;

public class EntradaVaziaException extends Exception {

  public EntradaVaziaException() {
    super("Entrada vazia.");
  }
  
}
